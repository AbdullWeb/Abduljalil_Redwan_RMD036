// Mobile menu toggle
const menuToggle = document.getElementById('menu-toggle');
const navLinks = document.getElementById('nav-links');

menuToggle.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
    });
});

// Portfolio data (you can customize this with your actual projects)
const portfolioItems = [
    {
        title: "Online Bookstore",
        description: "A full-stack e-commerce platform for buying and selling books. Features user authentication, shopping cart, payment processing, and admin dashboard for inventory management.",
        tags: ["React", "Bootstrap", "Node.js", "Express", "MongoDB", "Full-Stack"],
        icon: "fas fa-book"
    },
    {
        title: "Portfolio Website",
        description: "A responsive, full-stack portfolio website with dynamic content management, blog functionality, and contact form with email integration.",
        tags: ["HTML", "CSS", "Bootstrap", "JavaScript", "Node.js", "Responsive"],
        icon: "fas fa-laptop-code"
    },
    
    {
        title: "University Management System",
        description: "Comprehensive database system for managing student records, courses, and faculty information with advanced reporting features.",
        tags: ["Database", "Java", "MySQL", "UI/UX"],
        icon: "fas fa-university"
    },
    
    
    
];

// Load portfolio items dynamically
function loadPortfolioItems() {
    const portfolioContainer = document.getElementById('portfolio-items');
    
    portfolioItems.forEach(item => {
        const portfolioItem = document.createElement('div');
        portfolioItem.className = 'portfolio-item';
        
        portfolioItem.innerHTML = `
            <div class="portfolio-item-img">
                <i class="${item.icon}"></i>
            </div>
            <div class="portfolio-item-content">
                <h3>${item.title}</h3>
                <p>${item.description}</p>
                <div class="portfolio-item-tags">
                    ${item.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
            </div>
        `;
        
        portfolioContainer.appendChild(portfolioItem);
    });
}

// Contact form submission (demo - would need backend integration)
const contactForm = document.getElementById('contactForm');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const subject = document.getElementById('subject').value;
        const message = document.getElementById('message').value;
        
        // In a real application, you would send this data to a server
        // For demo purposes, we'll just show an alert
        alert(`Thank you, ${name}! Your message has been received. I'll get back to you soon at ${email}.`);
        
        // Reset form
        contactForm.reset();
    });
}

// Set current year in footer
document.getElementById('currentYear').textContent = new Date().getFullYear();

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    loadPortfolioItems();
});